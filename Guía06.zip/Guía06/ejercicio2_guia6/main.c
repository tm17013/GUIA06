#include <stdio.h>
#include <stdlib.h>
struct nodo{
    int info;
    struct nodo *sig;
};
struct nodo2{
    int info;
    struct nodo2 *sig;
};
struct nodo *raiz =NULL;
struct nodo *raiz2 =NULL;

void insertar (int x) {
    struct nodo *nuevo;
    nuevo = malloc(sizeof(struct nodo));
    nuevo->info = x;
    if (raiz == NULL) {
        raiz = nuevo;
        nuevo->sig = NULL;
    } else {
        nuevo->sig = raiz;
        raiz = nuevo;
    }
}
    void insertar2 (int x) {
        struct nodo2 *nuevo;
        nuevo = malloc(sizeof(struct nodo));
        nuevo->info = x;
        if (raiz2 == NULL) {
            raiz2 = nuevo;
            nuevo->sig = NULL;
        } else {
            nuevo->sig = raiz2;
            raiz2 = nuevo;
        }
    }
        void imprimir(){
            struct nodo *reco=raiz;
            printf("Lista completa.\n");
            while (reco!=NULL){
                printf("%i",reco->info);
                reco=reco->sig;
            }
            printf("  ");
        }
        void imprimirx(){
            struct nodo2 *reco=raiz2;
            printf("Lista completa.\n");
            while (reco!=NULL){
                printf("%i",reco->info);
                reco=reco->sig;
            }
            printf("  ");
        }

int invertir(){
    if(raiz!=NULL){
        while(raiz!=NULL){
            struct nodo *bor=raiz;
            insertar2(bor->info);
            raiz=raiz->sig;
            free(bor);
        }
    }else{
        return -1;
    }
}
        int main() {
    insertar(9);
    insertar(0);
    insertar(8);
    imprimir();
    invertir();
    imprimirx();
    return 0;
}

